package pe.edu.upc.hireready1.servicesinterfaces;

import pe.edu.upc.hireready1.entities.SimulationResponse;
import java.util.List;
import java.util.Optional;

public interface ISimulationResponseService {
    public List<SimulationResponse> list();
    public SimulationResponse insert(SimulationResponse s);
    public Optional<SimulationResponse> listId(int id);
    public void update(SimulationResponse s);
    public void delete(int id);
}