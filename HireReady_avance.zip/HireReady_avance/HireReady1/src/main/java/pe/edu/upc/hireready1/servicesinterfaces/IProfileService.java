package pe.edu.upc.hireready1.servicesinterfaces;

import pe.edu.upc.hireready1.entities.Profile;
import java.util.List;
import java.util.Optional;

public interface IProfileService {
    public List<Profile> list();
    public Profile insert(Profile p);
    public Optional<Profile> listId(int id);
    public void update(Profile p);
    public void delete(int id);
}