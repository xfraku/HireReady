package pe.edu.upc.hireready1.dtos;

import java.util.List;

public class UserDTO {

    private Long userId;
    private String dni;
    private String personalEmail;
    private String firstName;
    private String secondName;
    private String paternalSurname;
    private String maternalSurname;
    private String languagePref;
    private boolean onboardingDone;
    private boolean isVerified;
    private boolean isDeleted;

    // Relaciones simplificadas
    private List<Long> roleIds;
    private Long profileId;

    // Constructor vacío
    public UserDTO() {}

    // Constructor completo
    public UserDTO(Long userId, String dni, String personalEmail, String firstName,
                   String secondName, String paternalSurname, String maternalSurname,
                   String languagePref, boolean onboardingDone, boolean isVerified,
                   boolean isDeleted, List<Long> roleIds, Long profileId) {

        this.userId = userId;
        this.dni = dni;
        this.personalEmail = personalEmail;
        this.firstName = firstName;
        this.secondName = secondName;
        this.paternalSurname = paternalSurname;
        this.maternalSurname = maternalSurname;
        this.languagePref = languagePref;
        this.onboardingDone = onboardingDone;
        this.isVerified = isVerified;
        this.isDeleted = isDeleted;
        this.roleIds = roleIds;
        this.profileId = profileId;
    }

    // Getters y Setters

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getPersonalEmail() {
        return personalEmail;
    }

    public void setPersonalEmail(String personalEmail) {
        this.personalEmail = personalEmail;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getSecondName() {
        return secondName;
    }

    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }

    public String getPaternalSurname() {
        return paternalSurname;
    }

    public void setPaternalSurname(String paternalSurname) {
        this.paternalSurname = paternalSurname;
    }

    public String getMaternalSurname() {
        return maternalSurname;
    }

    public void setMaternalSurname(String maternalSurname) {
        this.maternalSurname = maternalSurname;
    }

    public String getLanguagePref() {
        return languagePref;
    }

    public void setLanguagePref(String languagePref) {
        this.languagePref = languagePref;
    }

    public boolean isOnboardingDone() {
        return onboardingDone;
    }

    public void setOnboardingDone(boolean onboardingDone) {
        this.onboardingDone = onboardingDone;
    }

    public boolean isVerified() {
        return isVerified;
    }

    public void setVerified(boolean verified) {
        isVerified = verified;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }

    public List<Long> getRoleIds() {
        return roleIds;
    }

    public void setRoleIds(List<Long> roleIds) {
        this.roleIds = roleIds;
    }

    public Long getProfileId() {
        return profileId;
    }

    public void setProfileId(Long profileId) {
        this.profileId = profileId;
    }
}