package pe.edu.upc.hireready1.servicesinterfaces;

import pe.edu.upc.hireready1.entities.ProfileSkills;
import java.util.List;
import java.util.Optional;

public interface IProfileSkillsService {
    public List<ProfileSkills> list();
    public ProfileSkills insert(ProfileSkills p);
    public Optional<ProfileSkills> listId(int id);
    public void update(ProfileSkills p);
    public void delete(int id);
}