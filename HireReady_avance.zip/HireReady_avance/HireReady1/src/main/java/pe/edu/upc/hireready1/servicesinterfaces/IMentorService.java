package pe.edu.upc.hireready1.servicesinterfaces;

import pe.edu.upc.hireready1.entities.Mentor;
import java.util.List;
import java.util.Optional;

public interface IMentorService {
    public List<Mentor> list();
    public Mentor insert(Mentor m);
    public Optional<Mentor> listId(int id);
    public void update(Mentor m);
    public void delete(int id);
}