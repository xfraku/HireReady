package pe.edu.upc.hireready1.dtos;

public class RolDTO {

    private Long rolId;
    private String rolType;

    // Constructor vacío
    public RolDTO() {}

    // Constructor completo
    public RolDTO(Long rolId, String rolType) {
        this.rolId = rolId;
        this.rolType = rolType;
    }

    // Getters y Setters

    public Long getRolId() {
        return rolId;
    }

    public void setRolId(Long rolId) {
        this.rolId = rolId;
    }

    public String getRolType() {
        return rolType;
    }

    public void setRolType(String rolType) {
        this.rolType = rolType;
    }
}