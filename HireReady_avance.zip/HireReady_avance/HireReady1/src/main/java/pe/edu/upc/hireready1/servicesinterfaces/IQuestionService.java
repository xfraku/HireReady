package pe.edu.upc.hireready1.servicesinterfaces;

import pe.edu.upc.hireready1.entities.Question;
import java.util.List;
import java.util.Optional;

public interface IQuestionService {
    public List<Question> list();
    public Question insert(Question q);
    public Optional<Question> listId(int id);
    public void update(Question q);
    public void delete(int id);
}