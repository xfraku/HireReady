package pe.edu.upc.hireready1.dtos;

public class FeedbackDTO {

    private Long feedbackId;
    private String frequentErrors;
    private String recommendation;

    // En lugar del objeto SimulationResult completo
    private Long resultId;

    // Constructor vacío
    public FeedbackDTO() {}

    // Constructor completo
    public FeedbackDTO(Long feedbackId, String frequentErrors, String recommendation, Long resultId) {
        this.feedbackId = feedbackId;
        this.frequentErrors = frequentErrors;
        this.recommendation = recommendation;
        this.resultId = resultId;
    }

    // Getters y Setters

    public Long getFeedbackId() {
        return feedbackId;
    }

    public void setFeedbackId(Long feedbackId) {
        this.feedbackId = feedbackId;
    }

    public String getFrequentErrors() {
        return frequentErrors;
    }

    public void setFrequentErrors(String frequentErrors) {
        this.frequentErrors = frequentErrors;
    }

    public String getRecommendation() {
        return recommendation;
    }

    public void setRecommendation(String recommendation) {
        this.recommendation = recommendation;
    }

    public Long getResultId() {
        return resultId;
    }

    public void setResultId(Long resultId) {
        this.resultId = resultId;
    }
}