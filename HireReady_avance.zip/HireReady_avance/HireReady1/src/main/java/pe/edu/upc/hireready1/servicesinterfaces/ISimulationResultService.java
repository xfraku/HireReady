package pe.edu.upc.hireready1.servicesinterfaces;

import pe.edu.upc.hireready1.entities.SimulationResult;
import java.util.List;
import java.util.Optional;

public interface ISimulationResultService {
    public List<SimulationResult> list();
    public SimulationResult insert(SimulationResult s);
    public Optional<SimulationResult> listId(int id);
    public void update(SimulationResult s);
    public void delete(int id);
}