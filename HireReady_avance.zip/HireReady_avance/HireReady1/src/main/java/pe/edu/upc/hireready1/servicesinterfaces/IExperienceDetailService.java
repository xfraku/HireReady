package pe.edu.upc.hireready1.servicesinterfaces;

import pe.edu.upc.hireready1.entities.ExperienceDetail;
import java.util.List;
import java.util.Optional;

public interface IExperienceDetailService {
    public List<ExperienceDetail> list();
    public ExperienceDetail insert(ExperienceDetail e);
    public Optional<ExperienceDetail> listId(int id);
    public void update(ExperienceDetail e);
    public void delete(int id);
}