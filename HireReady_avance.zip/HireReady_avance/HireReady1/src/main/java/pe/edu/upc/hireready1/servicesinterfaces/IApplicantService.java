package pe.edu.upc.hireready1.servicesinterfaces;

import pe.edu.upc.hireready1.entities.Applicant;
import java.util.List;
import java.util.Optional;

public interface IApplicantService {
    public List<Applicant> list();
    public Applicant insert(Applicant a);
    public Optional<Applicant> listId(int id);
    public void update(Applicant a);
    public void delete(int id);
}