package pe.edu.upc.hireready1.servicesinterfaces;

import pe.edu.upc.hireready1.entities.ModelAnswer;
import java.util.List;
import java.util.Optional;

public interface IModelAnswerService {
    public List<ModelAnswer> list();
    public ModelAnswer insert(ModelAnswer m);
    public Optional<ModelAnswer> listId(int id);
    public void update(ModelAnswer m);
    public void delete(int id);
}