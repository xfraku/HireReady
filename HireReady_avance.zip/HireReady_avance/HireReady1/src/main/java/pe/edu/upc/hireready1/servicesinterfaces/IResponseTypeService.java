package pe.edu.upc.hireready1.servicesinterfaces;

import pe.edu.upc.hireready1.entities.ResponseType;
import java.util.List;
import java.util.Optional;

public interface IResponseTypeService {
    public List<ResponseType> list();
    public ResponseType insert(ResponseType r);
    public Optional<ResponseType> listId(int id);
    public void update(ResponseType r);
    public void delete(int id);
}