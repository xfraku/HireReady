package pe.edu.upc.hireready1.dtos;

public class MentorDTO {

    private Long userId;
    private String dni;
    private String personalEmail;
    private String firstName;
    private String secondName;
    private String paternalSurname;
    private String maternalSurname;
    private String languagePref;

    private Long mentorId;
    private String bachelorDegreeCertificateUrl;
    private String professionalDegreeCertificateUrl;
    private String workplaceName;
    private String workEmail;
    private String RUC;

    // Constructor vacío
    public MentorDTO() {}

    // Constructor completo
    public MentorDTO(Long userId, String dni, String personalEmail, String firstName, String secondName,
                     String paternalSurname, String maternalSurname, String languagePref,
                     Long mentorId, String bachelorDegreeCertificateUrl,
                     String professionalDegreeCertificateUrl,
                     String workplaceName, String workEmail, String RUC) {

        this.userId = userId;
        this.dni = dni;
        this.personalEmail = personalEmail;
        this.firstName = firstName;
        this.secondName = secondName;
        this.paternalSurname = paternalSurname;
        this.maternalSurname = maternalSurname;
        this.languagePref = languagePref;
        this.mentorId = mentorId;
        this.bachelorDegreeCertificateUrl = bachelorDegreeCertificateUrl;
        this.professionalDegreeCertificateUrl = professionalDegreeCertificateUrl;
        this.workplaceName = workplaceName;
        this.workEmail = workEmail;
        this.RUC = RUC;
    }

    // Getters y Setters

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getPersonalEmail() {
        return personalEmail;
    }

    public void setPersonalEmail(String personalEmail) {
        this.personalEmail = personalEmail;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getSecondName() {
        return secondName;
    }

    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }

    public String getPaternalSurname() {
        return paternalSurname;
    }

    public void setPaternalSurname(String paternalSurname) {
        this.paternalSurname = paternalSurname;
    }

    public String getMaternalSurname() {
        return maternalSurname;
    }

    public void setMaternalSurname(String maternalSurname) {
        this.maternalSurname = maternalSurname;
    }

    public String getLanguagePref() {
        return languagePref;
    }

    public void setLanguagePref(String languagePref) {
        this.languagePref = languagePref;
    }

    public Long getMentorId() {
        return mentorId;
    }

    public void setMentorId(Long mentorId) {
        this.mentorId = mentorId;
    }

    public String getBachelorDegreeCertificateUrl() {
        return bachelorDegreeCertificateUrl;
    }

    public void setBachelorDegreeCertificateUrl(String bachelorDegreeCertificateUrl) {
        this.bachelorDegreeCertificateUrl = bachelorDegreeCertificateUrl;
    }

    public String getProfessionalDegreeCertificateUrl() {
        return professionalDegreeCertificateUrl;
    }

    public void setProfessionalDegreeCertificateUrl(String professionalDegreeCertificateUrl) {
        this.professionalDegreeCertificateUrl = professionalDegreeCertificateUrl;
    }

    public String getWorkplaceName() {
        return workplaceName;
    }

    public void setWorkplaceName(String workplaceName) {
        this.workplaceName = workplaceName;
    }

    public String getWorkEmail() {
        return workEmail;
    }

    public void setWorkEmail(String workEmail) {
        this.workEmail = workEmail;
    }

    public String getRUC() {
        return RUC;
    }

    public void setRUC(String RUC) {
        this.RUC = RUC;
    }
}