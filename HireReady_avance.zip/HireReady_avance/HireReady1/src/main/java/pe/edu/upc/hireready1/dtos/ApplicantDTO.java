package pe.edu.upc.hireready1.dtos;

public class ApplicantDTO {

    private Long userId;
    private String dni;
    private String personalEmail;
    private String firstName;
    private String secondName;
    private String paternalSurname;
    private String maternalSurname;
    private String languagePref;

    private Long applicantId;
    private String universityName;
    private String universityEmail;
    private String universityCertificateUrl;

    // Constructor vacío
    public ApplicantDTO() {}

    // Constructor completo
    public ApplicantDTO(Long userId, String dni, String personalEmail, String firstName, String secondName,
                        String paternalSurname, String maternalSurname, String languagePref,
                        Long applicantId, String universityName, String universityEmail, String universityCertificateUrl) {
        this.userId = userId;
        this.dni = dni;
        this.personalEmail = personalEmail;
        this.firstName = firstName;
        this.secondName = secondName;
        this.paternalSurname = paternalSurname;
        this.maternalSurname = maternalSurname;
        this.languagePref = languagePref;
        this.applicantId = applicantId;
        this.universityName = universityName;
        this.universityEmail = universityEmail;
        this.universityCertificateUrl = universityCertificateUrl;
    }

    // Getters y Setters

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getPersonalEmail() {
        return personalEmail;
    }

    public void setPersonalEmail(String personalEmail) {
        this.personalEmail = personalEmail;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getSecondName() {
        return secondName;
    }

    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }

    public String getPaternalSurname() {
        return paternalSurname;
    }

    public void setPaternalSurname(String paternalSurname) {
        this.paternalSurname = paternalSurname;
    }

    public String getMaternalSurname() {
        return maternalSurname;
    }

    public void setMaternalSurname(String maternalSurname) {
        this.maternalSurname = maternalSurname;
    }

    public String getLanguagePref() {
        return languagePref;
    }

    public void setLanguagePref(String languagePref) {
        this.languagePref = languagePref;
    }

    public Long getApplicantId() {
        return applicantId;
    }

    public void setApplicantId(Long applicantId) {
        this.applicantId = applicantId;
    }

    public String getUniversityName() {
        return universityName;
    }

    public void setUniversityName(String universityName) {
        this.universityName = universityName;
    }

    public String getUniversityEmail() {
        return universityEmail;
    }

    public void setUniversityEmail(String universityEmail) {
        this.universityEmail = universityEmail;
    }

    public String getUniversityCertificateUrl() {
        return universityCertificateUrl;
    }

    public void setUniversityCertificateUrl(String universityCertificateUrl) {
        this.universityCertificateUrl = universityCertificateUrl;
    }
}