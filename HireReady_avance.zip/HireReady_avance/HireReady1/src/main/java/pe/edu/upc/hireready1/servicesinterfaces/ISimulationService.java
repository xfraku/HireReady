package pe.edu.upc.hireready1.servicesinterfaces;

import pe.edu.upc.hireready1.entities.Simulation;
import java.util.List;
import java.util.Optional;

public interface ISimulationService {
    public List<Simulation> list();
    public Simulation insert(Simulation s);
    public Optional<Simulation> listId(int id);
    public void update(Simulation s);
    public void delete(int id);
}